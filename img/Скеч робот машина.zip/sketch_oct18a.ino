/*
   ESP32 + RemoteXY
   Акустикалық жалын сөндіргіш робот

   Екі режим:
   1. Қолмен басқару — RemoteXY Wi-Fi
   2. Автономды режим — физикалық кнопка арқылы

   Автономды алгоритм:
   Іздеу -> жалынды табу -> 1 секунд тоқтау ->
   алға жүру -> 10 см-де тоқтау ->
   25 Гц дыбыс + серво ->
   от сөнгенде артқа жүру ->
   қайта жалын іздеу -> таппаса тоқтау
*/

#define REMOTEXY_MODE__WIFI_POINT

#include <WiFi.h>
#include <RemoteXY.h>
#include <ESP32Servo.h>
#include <esp_timer.h>

// ============================================================
//                       REMOTEXY
// ============================================================

#define REMOTEXY_WIFI_SSID       "RemoteXY"
#define REMOTEXY_WIFI_PASSWORD   "12345678"
#define REMOTEXY_SERVER_PORT     6377
#define REMOTEXY_ACCESS_PASSWORD "0000"

#pragma pack(push, 1)

uint8_t const PROGMEM RemoteXY_CONF_PROGMEM[] =
  { 255,5,0,0,0,70,0,19,0,0,0,49,49,49,49,0,31,1,106,200,
  1,1,5,0,1,72,146,24,24,0,2,31,0,1,17,148,24,24,0,2,
  31,0,2,30,92,44,22,0,2,26,31,31,79,78,0,79,70,70,0,1,
  39,9,24,24,0,2,31,0,1,41,50,24,24,0,2,31,0 };

struct {
  uint8_t button_01;      // Алға
  uint8_t button_02;      // Артқа
  uint8_t switch_01;      // Дыбыс + серво
  uint8_t button_03;      // Солға
  uint8_t button_04;      // Оңға
  uint8_t connect_flag;
} RemoteXY;

#pragma pack(pop)

// ============================================================
//                         ПИНДЕР
// ============================================================

// L298N A арнасы -> OUT1/OUT2 -> ОҢ ЖАҚ екі мотор
#define ENA 19
#define IN1 18
#define IN2 5

// L298N B арнасы -> OUT3/OUT4 -> СОЛ ЖАҚ екі мотор
#define ENB 4
#define IN3 17
#define IN4 16

// Динамик күшейткішінің LIN кірісі
#define SPK_PIN 25

// Сервомотор
#define SERVO_PIN 13

// Жалын датчигінің AO пині
#define FLAME_PIN 34

// HC-SR04
#define TRIG_PIN 26
#define ECHO_PIN 27

// Автономды режим кнопкасы
#define MODE_BUTTON_PIN 32

// Автономды режим LED шамы
#define AUTO_LED_PIN 33

// ============================================================
//                    НЕГІЗГІ БАПТАУЛАР
// ============================================================

// Егер бір жақтағы мотор кері айналса,
// сәйкес false мәнін true етіңіз

const bool LEFT_MOTOR_REVERSED  = false;
const bool RIGHT_MOTOR_REVERSED = false;

// Көп жалын датчиктерінде жалын жақындағанда
// аналогтық көрсеткіш төмендейді
const bool FLAME_LOW_MEANS_FIRE = true;

// Жалын датчигінің сезімталдығы
// Кішірейтсеңіз — сезімтал болады
// Үлкейтсеңіз — жалған іске қосылу азаяды
const int FLAME_MARGIN = 350;

int flameBaseline = 3000;
int flameThreshold = 2500;
int lastFlameValue = 4095;

// Жалыннан тоқтайтын арақашықтық
const int STOP_DISTANCE_CM = 10;

// 10 см көрсеткішін неше рет растау керек
const int DISTANCE_CONFIRM_COUNT = 3;

// Кнопканың дірілін сүзу
const unsigned long BUTTON_DEBOUNCE_MS = 50;

// Жалынды қанша уақыт растау керек
const unsigned long FLAME_CONFIRM_MS = 150;

// Алға келе жатқанда жалын жоғалса
const unsigned long FLAME_LOST_MS = 600;

// Жалынды тапқаннан кейінгі тоқтау
const unsigned long TARGET_PAUSE_MS = 1000;

// Жалынды іздеу уақыты
const unsigned long SEARCH_TIMEOUT_MS = 7000;

// Жалынға қарай жүрудің максималды уақыты
const unsigned long APPROACH_TIMEOUT_MS = 15000;

// Ультрадыбыс өлшемдерінің аралығы
const unsigned long DISTANCE_INTERVAL_MS = 70;

// Дыбыс кемінде 1 секунд жұмыс істейді
const unsigned long MIN_EXTINGUISH_MS = 1000;

// Жалын 1,5 секунд көрінбесе — сөнді деп саналады
const unsigned long FLAME_OUT_CONFIRM_MS = 1500;

// Дыбыс пен күшейткішті қорғау үшін
// максималды өшіру уақыты
const unsigned long MAX_EXTINGUISH_MS = 20000;

// Артқа жүру уақыты
const unsigned long REVERSE_TIME_MS = 1500;

// Serial Monitor шығару аралығы
const unsigned long SERIAL_INTERVAL_MS = 500;

// ============================================================
//                      СЕРВОМОТОР
// ============================================================

const int SERVO_MIN_ANGLE    = 50;
const int SERVO_MAX_ANGLE    = 130;
const int SERVO_CENTER_ANGLE = 90;

// Серво жылдамдығы
const unsigned long SERVO_STEP_MS = 24;

Servo myServo;

int servoPos = SERVO_CENTER_ANGLE;
int servoDirection = 1;

unsigned long lastServoStepMs = 0;

bool extinguisherWasOn = false;

// ============================================================
//                    25 ГЦ ДЫБЫС
// ============================================================

// 25 Гц = 40 мс толық период
// 20 мс HIGH + 20 мс LOW
const uint64_t SOUND_HALF_PERIOD_US = 20000;

volatile bool soundEnable = false;
volatile bool soundPinState = false;

bool soundGeneratorReady = false;

esp_timer_handle_t soundTimer = nullptr;

// Әр 20 мс сайын орындалатын функция
void soundTimerCallback(void *parameter) {
  (void)parameter;

  if (soundEnable) {
    soundPinState = !soundPinState;

    digitalWrite(
      SPK_PIN,
      soundPinState ? HIGH : LOW
    );
  }
  else {
    soundPinState = false;
    digitalWrite(SPK_PIN, LOW);
  }
}

// 25 Гц генераторды іске қосу
void setupSoundGenerator() {
  pinMode(SPK_PIN, OUTPUT);
  digitalWrite(SPK_PIN, LOW);

  esp_timer_create_args_t timerArgs = {};

  timerArgs.callback = &soundTimerCallback;
  timerArgs.arg = nullptr;
  timerArgs.dispatch_method = ESP_TIMER_TASK;
  timerArgs.name = "sound25Hz";

  esp_err_t result =
    esp_timer_create(
      &timerArgs,
      &soundTimer
    );

  if (result == ESP_OK) {
    result =
      esp_timer_start_periodic(
        soundTimer,
        SOUND_HALF_PERIOD_US
      );

    soundGeneratorReady =
      (result == ESP_OK);
  }

  if (!soundGeneratorReady) {
    digitalWrite(SPK_PIN, LOW);

    Serial.println(
      "ERROR: 25 Hz generator іске қосылмады"
    );
  }
}

// Дыбысты қосу немесе өшіру
void setAcousticSound(bool enable) {
  if (!soundGeneratorReady) {
    soundEnable = false;
    digitalWrite(SPK_PIN, LOW);

    return;
  }

  soundEnable = enable;

  if (!enable) {
    soundPinState = false;
    digitalWrite(SPK_PIN, LOW);
  }
}

// ============================================================
//                     МОТОРДЫ БАСҚАРУ
// ============================================================

/*
   command:

    1  = алға
   -1  = артқа
    0  = тоқтау
*/

void setMotorChannel(
  int input1,
  int input2,
  int enablePin,
  int command,
  bool reversed
) {
  command = constrain(command, -1, 1);

  if (reversed) {
    command = -command;
  }

  if (command == 0) {
    digitalWrite(input1, LOW);
    digitalWrite(input2, LOW);
    digitalWrite(enablePin, LOW);

    return;
  }

  if (command > 0) {
    digitalWrite(input1, LOW);
    digitalWrite(input2, HIGH);
  }
  else {
    digitalWrite(input1, HIGH);
    digitalWrite(input2, LOW);
  }

  // PWM жоқ — толық қуат
  digitalWrite(enablePin, HIGH);
}

// Сол жақтағы екі мотор
void setLeftMotor(int command) {
  setMotorChannel(
    IN3,
    IN4,
    ENB,
    command,
    LEFT_MOTOR_REVERSED
  );
}

// Оң жақтағы екі мотор
void setRightMotor(int command) {
  setMotorChannel(
    IN1,
    IN2,
    ENA,
    command,
    RIGHT_MOTOR_REVERSED
  );
}

// Екі жақты бірге басқару
void driveRobot(
  int leftCommand,
  int rightCommand
) {
  setLeftMotor(leftCommand);
  setRightMotor(rightCommand);
}

// Барлық моторды тоқтату
void stopMotors() {
  driveRobot(0, 0);
}

// ============================================================
//                     ЖАЛЫН ДАТЧИГІ
// ============================================================

// Жалын датчигін бірнеше рет оқып,
// орташа мәнін шығару
int readFlameAverage() {
  long total = 0;

  for (int i = 0; i < 8; i++) {
    total += analogRead(FLAME_PIN);
  }

  lastFlameValue =
    (int)(total / 8);

  return lastFlameValue;
}

// Жалын бар-жоғын анықтау
bool flameDetected() {
  int value = readFlameAverage();

  if (FLAME_LOW_MEANS_FIRE) {
    return value < flameThreshold;
  }

  return value > flameThreshold;
}

// Қосылған кездегі автоматты калибровка
void calibrateFlameSensor() {
  Serial.println(
    "Flame calibration: 1.5 секунд отты жақындатпаңыз"
  );

  unsigned long startedAt = millis();

  long total = 0;
  int sampleCount = 0;

  while (millis() - startedAt < 1500) {
    total += analogRead(FLAME_PIN);
    sampleCount++;

    delay(5);
  }

  if (sampleCount > 0) {
    flameBaseline =
      (int)(total / sampleCount);
  }

  if (FLAME_LOW_MEANS_FIRE) {
    flameThreshold =
      flameBaseline - FLAME_MARGIN;

    flameThreshold =
      constrain(
        flameThreshold,
        100,
        4000
      );
  }
  else {
    flameThreshold =
      flameBaseline + FLAME_MARGIN;

    flameThreshold =
      constrain(
        flameThreshold,
        100,
        4000
      );
  }

  Serial.print("Flame baseline = ");
  Serial.println(flameBaseline);

  Serial.print("Flame threshold = ");
  Serial.println(flameThreshold);
}

// ============================================================
//                       HC-SR04
// ============================================================

long getDistanceCM() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);

  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);

  digitalWrite(TRIG_PIN, LOW);

  unsigned long duration =
    pulseIn(
      ECHO_PIN,
      HIGH,
      25000UL
    );

  // Жауап келмесе — алыс деп есептеу
  if (duration == 0) {
    return 999;
  }

  return (long)(duration / 58UL);
}

// ============================================================
//                 СЕРВОМОТОР ЖӘНЕ ДЫБЫС
// ============================================================

void updateExtinguisher(bool enable) {
  // Дыбысты қосу немесе өшіру
  setAcousticSound(enable);

  unsigned long currentTime = millis();

  if (enable) {
    // Жаңа қосылған кезде серво ортадан бастайды
    if (!extinguisherWasOn) {
      servoPos = SERVO_CENTER_ANGLE;
      servoDirection = 1;

      lastServoStepMs = currentTime;

      myServo.write(servoPos);
    }

    // Сервоны 50–130° арасында қозғалту
    if (
      currentTime - lastServoStepMs >=
      SERVO_STEP_MS
    ) {
      lastServoStepMs = currentTime;

      servoPos += servoDirection;

      if (servoPos >= SERVO_MAX_ANGLE) {
        servoPos = SERVO_MAX_ANGLE;
        servoDirection = -1;
      }
      else if (servoPos <= SERVO_MIN_ANGLE) {
        servoPos = SERVO_MIN_ANGLE;
        servoDirection = 1;
      }

      myServo.write(servoPos);
    }
  }
  else if (extinguisherWasOn) {
    // Өшкен кезде серво ортаға қайтады
    servoPos = SERVO_CENTER_ANGLE;
    servoDirection = 1;

    myServo.write(servoPos);
  }

  extinguisherWasOn = enable;
}

// ============================================================
//                REMOTEXY ҚОЛМЕН БАСҚАРУ
// ============================================================

void updateManualDrive() {
  bool forwardPressed =
    RemoteXY.button_01 != 0;

  bool reversePressed =
    RemoteXY.button_02 != 0;

  bool leftPressed =
    RemoteXY.button_03 != 0;

  bool rightPressed =
    RemoteXY.button_04 != 0;

  // Қарама-қарсы кнопкалар қатар басылса
  if (
    (forwardPressed && reversePressed) ||
    (leftPressed && rightPressed)
  ) {
    stopMotors();
    return;
  }

  // Солға
  if (leftPressed) {
    driveRobot(-1, 1);
  }

  // Оңға
  else if (rightPressed) {
    driveRobot(1, -1);
  }

  // Алға
  else if (forwardPressed) {
    driveRobot(1, 1);
  }

  // Артқа
  else if (reversePressed) {
    driveRobot(-1, -1);
  }

  // Ешқандай кнопка басылмаса
  else {
    stopMotors();
  }
}

void updateManualMode() {
  // Телефон ажыратылса — бәрі тоқтайды
  if (RemoteXY.connect_flag == 0) {
    stopMotors();
    updateExtinguisher(false);

    return;
  }

  bool manualExtinguisherOn =
    RemoteXY.switch_01 != 0;

  if (manualExtinguisherOn) {
    // Дыбыс кезінде моторлар тоқтайды
    stopMotors();
    updateExtinguisher(true);
  }
  else {
    updateExtinguisher(false);
    updateManualDrive();
  }
}

// ============================================================
//                  АВТОНОМДЫ РЕЖИМ КҮЙЛЕРІ
// ============================================================

enum AutoState : uint8_t {
  AUTO_IDLE,

  // Жалынды айналып іздеу
  AUTO_SEARCHING,

  // Жалынды тапқаннан кейін 1 секунд тоқтау
  AUTO_TARGET_PAUSE,

  // Жалынға қарай жүру
  AUTO_APPROACHING,

  // Дыбыс пен серво арқылы сөндіру
  AUTO_EXTINGUISHING,

  // От сөнгеннен кейін артқа жүру
  AUTO_REVERSING,

  // Жалын табылмағанда тоқтау
  AUTO_STOPPED
};

AutoState autoState = AUTO_IDLE;

bool autonomousMode = false;

unsigned long stateStartedAt = 0;

unsigned long flameConfirmStartedAt = 0;

unsigned long flameAbsentStartedAt = 0;

unsigned long lastFlameSeenAt = 0;

unsigned long lastDistanceReadAt = 0;

unsigned long lastSerialAt = 0;

long lastDistanceCM = 999;

int distanceNearHits = 0;

// Автономды күйді ауыстыру
void enterAutoState(AutoState newState) {
  autoState = newState;

  stateStartedAt = millis();

  flameConfirmStartedAt = 0;
  flameAbsentStartedAt = 0;

  distanceNearHits = 0;

  if (newState == AUTO_APPROACHING) {
    lastFlameSeenAt = millis();

    lastDistanceReadAt = 0;
    lastDistanceCM = 999;
  }
}

// Автономды режимді қосу немесе өшіру
void setAutonomousMode(bool enable) {
  autonomousMode = enable;

  // Автономды режимде LED жанады
  digitalWrite(
    AUTO_LED_PIN,
    enable ? HIGH : LOW
  );

  stopMotors();
  updateExtinguisher(false);

  if (enable) {
    enterAutoState(AUTO_SEARCHING);

    Serial.println(
      "MODE: AUTONOMOUS ON"
    );
  }
  else {
    enterAutoState(AUTO_IDLE);

    Serial.println(
      "MODE: MANUAL REMOTEXY"
    );
  }
}

// ============================================================
//                АВТОНОМДЫ РЕЖИМ АЛГОРИТМІ
// ============================================================

void updateAutonomousMode() {
  unsigned long currentTime = millis();

  bool fire = flameDetected();

  switch (autoState) {

    // ========================================================
    // 1. ЖАЛЫНДЫ ІЗДЕУ
    // ========================================================

    case AUTO_SEARCHING:

      updateExtinguisher(false);

      /*
         Жалын көрінсе, бірден тоқтайды.
         Содан кейін 150 мс растау жасайды.
      */

      if (fire) {
        stopMotors();

        if (flameConfirmStartedAt == 0) {
          flameConfirmStartedAt =
            currentTime;
        }

        if (
          currentTime - flameConfirmStartedAt >=
          FLAME_CONFIRM_MS
        ) {
          enterAutoState(
            AUTO_TARGET_PAUSE
          );
        }
      }
      else {
        flameConfirmStartedAt = 0;

        // Өз осімен солға айналып іздеу
        driveRobot(-1, 1);
      }

      /*
         Белгіленген уақытта жалын табылмаса,
         робот тоқтайды.
      */

      if (
        currentTime - stateStartedAt >=
        SEARCH_TIMEOUT_MS
      ) {
        stopMotors();

        enterAutoState(
          AUTO_STOPPED
        );
      }

      break;

    // ========================================================
    // 2. ЖАЛЫНДЫ ТАПҚАННАН КЕЙІН ТОҚТАУ
    // ========================================================

    case AUTO_TARGET_PAUSE:

      stopMotors();
      updateExtinguisher(false);

      if (
        currentTime - stateStartedAt >=
        TARGET_PAUSE_MS
      ) {
        if (fire) {
          enterAutoState(
            AUTO_APPROACHING
          );
        }
        else {
          // Жалын жоғалып кетсе қайта іздейді
          enterAutoState(
            AUTO_SEARCHING
          );
        }
      }

      break;

    // ========================================================
    // 3. ЖАЛЫНҒА ҚАРАЙ ЖҮРУ
    // ========================================================

    case AUTO_APPROACHING:

      updateExtinguisher(false);

      // Жалын әлі көрініп тұрса
      if (fire) {
        lastFlameSeenAt = currentTime;
      }

      // Жалын жоғалса — қайта іздеу
      else if (
        currentTime - lastFlameSeenAt >=
        FLAME_LOST_MS
      ) {
        stopMotors();

        enterAutoState(
          AUTO_SEARCHING
        );

        break;
      }

      // Ультрадыбысты әр 70 мс сайын оқу
      if (
        currentTime - lastDistanceReadAt >=
        DISTANCE_INTERVAL_MS
      ) {
        lastDistanceReadAt =
          currentTime;

        lastDistanceCM =
          getDistanceCM();

        // 2–10 см аралығы
        if (
          lastDistanceCM >= 2 &&
          lastDistanceCM <= STOP_DISTANCE_CM
        ) {
          distanceNearHits++;
        }
        else {
          distanceNearHits = 0;
        }
      }

      // 10 см үш рет қатарынан расталса
      if (
        distanceNearHits >=
        DISTANCE_CONFIRM_COUNT
      ) {
        stopMotors();

        enterAutoState(
          AUTO_EXTINGUISHING
        );

        break;
      }

      // Өте ұзақ жүріп кетуден қорғау
      if (
        currentTime - stateStartedAt >=
        APPROACH_TIMEOUT_MS
      ) {
        stopMotors();

        enterAutoState(
          AUTO_STOPPED
        );

        break;
      }

      // Жалынға қарай алға жүру
      driveRobot(1, 1);

      break;

    // ========================================================
    // 4. ЖАЛЫНДЫ СӨНДІРУ
    // ========================================================

    case AUTO_EXTINGUISHING:

      stopMotors();

      // 25 Гц дыбыс пен серво бірге қосылады
      updateExtinguisher(true);

      /*
         Дыбыс кемінде 1 секунд жұмыс істегеннен кейін
         жалынның өшкенін тексереді.
      */

      if (
        currentTime - stateStartedAt >=
        MIN_EXTINGUISH_MS
      ) {
        // Жалын әлі бар болса
        if (fire) {
          flameAbsentStartedAt = 0;
        }

        // Жалын көрінбесе
        else {
          if (flameAbsentStartedAt == 0) {
            flameAbsentStartedAt =
              currentTime;
          }

          /*
             Жалын 1,5 секунд бойы көрінбесе,
             от сөнді деп есептеледі.
          */

          if (
            currentTime - flameAbsentStartedAt >=
            FLAME_OUT_CONFIRM_MS
          ) {
            updateExtinguisher(false);

            enterAutoState(
              AUTO_REVERSING
            );

            break;
          }
        }
      }

      /*
         20 секундта жалын өшпесе,
         динамик пен күшейткішті қорғау үшін тоқтайды.
      */

      if (
        currentTime - stateStartedAt >=
        MAX_EXTINGUISH_MS
      ) {
        updateExtinguisher(false);

        enterAutoState(
          AUTO_STOPPED
        );
      }

      break;

    // ========================================================
    // 5. ОТ СӨНГЕННЕН КЕЙІН АРТҚА ЖҮРУ
    // ========================================================

    case AUTO_REVERSING:

      updateExtinguisher(false);

      // Екі жақтағы мотор артқа айналады
      driveRobot(-1, -1);

      if (
        currentTime - stateStartedAt >=
        REVERSE_TIME_MS
      ) {
        stopMotors();

        // Қайта жалын іздеу
        enterAutoState(
          AUTO_SEARCHING
        );
      }

      break;

    // ========================================================
    // 6. ЖАЛЫН ТАБЫЛМАҒАНДА ТОҚТАУ
    // ========================================================

    case AUTO_STOPPED:

      stopMotors();
      updateExtinguisher(false);

      /*
         LED жанып тұрады.
         Қолмен басқару режиміне өту үшін
         физикалық кнопканы қайта басу керек.
      */

      break;

    // ========================================================
    // АВТОНОМДЫ РЕЖИМ ӨШІРУЛІ
    // ========================================================

    case AUTO_IDLE:
    default:

      stopMotors();
      updateExtinguisher(false);

      break;
  }

  // ==========================================================
  // SERIAL MONITOR АҚПАРАТЫ
  // ==========================================================

  if (
    currentTime - lastSerialAt >=
    SERIAL_INTERVAL_MS
  ) {
    lastSerialAt = currentTime;

    Serial.print("AUTO state=");
    Serial.print((int)autoState);

    Serial.print(" flame=");
    Serial.print(lastFlameValue);

    Serial.print(" threshold=");
    Serial.print(flameThreshold);

    Serial.print(" distance=");
    Serial.println(lastDistanceCM);
  }
}

// ============================================================
//                   ФИЗИКАЛЫҚ КНОПКА
// ============================================================

bool lastButtonReading = HIGH;
bool stableButtonState = HIGH;

unsigned long buttonChangedAt = 0;

void updateModeButton() {
  bool reading =
    digitalRead(MODE_BUTTON_PIN);

  unsigned long currentTime =
    millis();

  // Кнопка жағдайы өзгерсе
  if (reading != lastButtonReading) {
    lastButtonReading = reading;
    buttonChangedAt = currentTime;
  }

  // 50 мс тұрақты тұрғаннан кейін ғана қабылдау
  if (
    currentTime - buttonChangedAt >=
    BUTTON_DEBOUNCE_MS
  ) {
    if (reading != stableButtonState) {
      stableButtonState = reading;

      /*
         INPUT_PULLUP қолданылады:
         кнопка басылғанда GPIO32 = LOW
      */

      if (stableButtonState == LOW) {
        setAutonomousMode(
          !autonomousMode
        );
      }
    }
  }
}

// ============================================================
//                          SETUP
// ============================================================

void setup() {
  Serial.begin(115200);

  // Мотор пиндері
  pinMode(ENA, OUTPUT);
  pinMode(ENB, OUTPUT);

  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);
  pinMode(IN3, OUTPUT);
  pinMode(IN4, OUTPUT);

  // HC-SR04
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  digitalWrite(TRIG_PIN, LOW);

  // Жалын датчигі
  pinMode(FLAME_PIN, INPUT);

  // Физикалық кнопка
  pinMode(
    MODE_BUTTON_PIN,
    INPUT_PULLUP
  );

  // Автономды режим LED шамы
  pinMode(AUTO_LED_PIN, OUTPUT);
  digitalWrite(AUTO_LED_PIN, LOW);

  // Моторларды тоқтату
  stopMotors();

  // Сервомотор
  ESP32PWM::allocateTimer(0);

  myServo.setPeriodHertz(50);

  myServo.attach(
    SERVO_PIN,
    500,
    2400
  );

  myServo.write(
    SERVO_CENTER_ANGLE
  );

  // 25 Гц генератор
  setupSoundGenerator();

  updateExtinguisher(false);

  /*
     Алғашқы 1,5 секундта калибровка жасалады.
     Осы уақытта датчикке отты жақындатпаңыз.
  */

  calibrateFlameSensor();

  // RemoteXY Wi-Fi іске қосу
  RemoteXY_Init();

  // Алғашқы режим — қолмен басқару
  setAutonomousMode(false);
}

// ============================================================
//                           LOOP
// ============================================================

void loop() {
  // RemoteXY байланысын үзбей өңдеу
  RemoteXYEngine.handler();

  // Физикалық режим кнопкасын тексеру
  updateModeButton();

  if (autonomousMode) {
    /*
       Автономды режим телефон
       ажыратылса да жұмыс істейді.
    */

    updateAutonomousMode();
  }
  else {
    // Wi-Fi арқылы қолмен басқару
    updateManualMode();
  }
}